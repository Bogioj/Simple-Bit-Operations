#ifndef REVERSE_VECTOR_H
#define REVREVERSE_VECTOR_H

#include <vector>

void reverse_vector(std::vector<char>& v);

#endif